package com.cg.healthservice.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.NameNotFoundException;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;
import com.cg.healthservice.service.AppointmentService;
import com.cg.healthservice.service.DiagnosticCenterService;
import com.cg.healthservice.service.PatientService;


/**
 * @author sulekha
 * class for controller
 *
 */
@RestController
@RequestMapping("/healthservice")
public class HealthServiceController {

	@Autowired
	PatientService patientService;
	@Autowired
	DiagnosticCenterService diagnosticCenterService;
	@Autowired
	AppointmentService appointmentService;

	public static final Logger logger = Logger.getLogger(HealthServiceController.class);
	Patient patient=null;
	DiagnosticCenter diagnosticCenter=null;

	/*
	 * @author sulekha
	 * last modified 25/5/2019
	 * method for take input from request and 
	 * interact to patientService to save patient
	 * @param patient com.cg.healthservice.Patient
	 * @return org.springframework.http.ResponseEntity<Patient>
	 * 	*/
	@RequestMapping(method=RequestMethod.POST,value="/addPatient")
	public ResponseEntity<Patient> addPatient(@ModelAttribute Patient patient){
		Patient p=patientService.addPatient(patient);
		if(p==null) {
			return new ResponseEntity("Data not added..",HttpStatus.NOT_FOUND);	
		}
		return new ResponseEntity<Patient>(p,HttpStatus.OK);
	}


	/* @author sulekha
	 * last modified 22/5/2019
	 * used for get search by name form
	 * @param name java.lang.String
	 * @return org.springframework.http.ResponseEntity<List<Patient>>
	 * 	*/
	@RequestMapping(method=RequestMethod.GET,value="/searchByName")
	public ResponseEntity<List<Patient>> searchByName(@RequestParam("name") String name){
		List<Patient> patients=null;
		try {
			patients=patientService.searchByName(name);
		}catch(NameNotFoundException e) {
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Patient>>(patients,HttpStatus.OK);
	}

	/*
	 * @author sulekha
	 * last modified 25/5/2019
	 * method for take input from request and 
	 * interact to diagnosticCenterService to save diagnosticCenter
	 * @param patient com.cg.healthservice.DiagnosticCenter
	 * @return org.springframework.http.ResponseEntity<DiagnosticCenter>
	 * 
	 * 	*/
	@RequestMapping(method=RequestMethod.POST,value="/addDiagnostic")
	public ResponseEntity<DiagnosticCenter> addAll(@ModelAttribute DiagnosticCenter diagnosticCenter) {
		DiagnosticCenter dc=diagnosticCenterService.addDiagnosticCenter(diagnosticCenter);
		if(dc==null)
			return new ResponseEntity("Data not added..",HttpStatus.NOT_FOUND);
		return new ResponseEntity<DiagnosticCenter>(dc,HttpStatus.OK);
	}
	
	/* @author sulekha
	 * last modified 25/5/2019
	 * used for search DiagnosticCenter  by Test name
	 * @param name java.lang.String
	 * @return org.springframework.http.ResponseEntity<List<DiagnosticCenter>>
	 * 	*/
	@RequestMapping(method=RequestMethod.GET,value="/searchByTest")
	public ResponseEntity<List<DiagnosticCenter>> searchByTest(@RequestParam("test") String name){
		List<DiagnosticCenter> diagnosticList=new ArrayList<DiagnosticCenter>();
		try {
			diagnosticList=diagnosticCenterService.searchByTest(name);
		}catch(NoTestMatchingDiagnosticCenterFound e) {
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<DiagnosticCenter>>(diagnosticList,HttpStatus.OK);
	}

	/* @author sulekha
	 * last modified 25/5/2019
	 * used for search DiagnosticCenter  by location 
	 * @param name java.lang.String
	 * @return org.springframework.http.ResponseEntity<List<DiagnosticCenter>>
	 * 	*/
	@RequestMapping(method=RequestMethod.GET,value="/searchByLocation")
	public ResponseEntity<List<DiagnosticCenter>> searchByLocation(@RequestParam("location") String location){

		List<DiagnosticCenter> diagnosticList=null;
		try {
			diagnosticList=diagnosticCenterService.searchByLocation(location);
		}catch(NoDiagnosticCenterFoundException ex) {
			return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<DiagnosticCenter>>(diagnosticList,HttpStatus.OK);
	}

	/*
	 * @author sulekha
	 * last modified 25/5/2019
	 * method for take input from request and 
	 * interact to patientService to save appointment
	 * @param patient com.cg.healthservice.Appointment
	 * @return org.springframework.http.ResponseEntity<Appointment>
	 * 	*/
	@RequestMapping(method=RequestMethod.POST,value="/addAppointment")
	public ResponseEntity<Appointment> addAppointment(@RequestParam("pid") Integer pid, 
			@RequestParam("did") Integer did,
			@RequestParam("date") String date) {
		try {
			patient=patientService.searchById(pid);
			System.out.println("Controller...."+patient);
		}
		catch(IdNotFoundException ex) {
			return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
		try {
			diagnosticCenter=diagnosticCenterService.searchById(did);
			System.out.println("controller...."+diagnosticCenter);
		}catch(NoDiagnosticCenterFoundException ex) {
			return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
		LocalDate localDate=null;
		try {
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("MM/dd/yy");
			localDate=LocalDate.parse(date,formatter);
			System.out.println(date);
		}catch(Exception e) {
			return new ResponseEntity("Date Format is invalid",HttpStatus.NOT_FOUND);
		}
		Appointment appointment=new Appointment();
		appointment.setPatient(patient);
		appointment.setDiagnosticCenter(diagnosticCenter);
		appointment.setDate(localDate);
		Appointment appointmentOne=appointmentService.addAppointment(appointment);
		if(appointmentOne==null)
			return new ResponseEntity("Data not added..",HttpStatus.NOT_FOUND);	
		return new ResponseEntity<Appointment>(appointment,HttpStatus.OK);	
	}

}
