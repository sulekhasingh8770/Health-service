package com.cg.healthservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dao.DiagnosticCenterDao;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;

/**
 * @author sulekha
 * class used to perform business operation and interact with DiagnosticCenterRepository
 * 
 */
@Service("diagnosticCenterService")
public class DiagnosticCenterServiceImpl implements DiagnosticCenterService {

	@Autowired
	DiagnosticCenterDao diagnosticCenterDao;
	static int id=300;
	static int testId=20;
	/* @author sulekha
	 * last modified- 25/05/2019
	 * perform business logic on diagnosticCenter object and interact with dao to persist object  
	 * @see com.cg.healthservice.service.DiagnosticCenterService#addDiagnosticCenter(com.cg.healthservice.dto.DiagnosticCenter)
	 */
	@Override
	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		diagnosticCenter.setId(id);
		for(Test t: diagnosticCenter.getTests()) {
			t.setId(testId);
			testId++;
		}
		id++;
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("DiagnosticService addDiagnosticCenter(DiagnosticCenter) is executed!");
		}
		return diagnosticCenterDao.save(diagnosticCenter);
	}

	/* @author sulekha
	 * last modified-25/05/2019
	 * interacting with repository to get the diagnosticCenter records using location
	 * @param location java.lang.String
	 * @return List<DiagnosticCenter>
	 * @throws com.cg.healthservice.exception.NoDiagnosticCenterFoundException if no record returned from repository
	 * @see com.cg.healthservice.service.DiagnosticCenterService#searchByLocation(java.lang.String)
	 */
	@Override
	public List<DiagnosticCenter> searchByLocation(String location) {
		System.out.println("service...."+location);
		List<DiagnosticCenter> diagnosticCenters=diagnosticCenterDao.findByLocation(location);
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("DiagnosticService searchByLocation(String) is executed!");
		}
		if(diagnosticCenters.isEmpty()) {
			HealthServiceController.logger.error("Given location is invalid "+new NoDiagnosticCenterFoundException());
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		}
		return diagnosticCenters;
	}

	/*
	 * interacting with repository to get the diagnosticCenter records using test name
	 * @param location java.lang.String
	 * @return List<DiagnosticCenter>
	 * @throws com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFoundException if no record returned from repository
	 * @see com.cg.healthservice.service.DiagnosticCenterService#searchByTest(java.lang.String)
	 */
	@Override
	public List<DiagnosticCenter> searchByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>(); 
		diagnosticCenters=diagnosticCenterDao.findByTest(name);
		System.out.println(diagnosticCenters);
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("DiagnosticService searchByTest(String) is executed!");
		}
		if(diagnosticCenters.isEmpty()) {
			HealthServiceController.logger.error("Given test is invalid "+new NoTestMatchingDiagnosticCenterFound());
			throw new NoTestMatchingDiagnosticCenterFound("Matching Diagnostic center Not found");
		}
		return diagnosticCenters;
	}

	/* @author sulekha
	 * last modified- 25/05/2019
	 * interacting with repository to get the diagnosticCenter records using id
	 * @param id int
	 * @return DiagnosticCenter
	 * @throws com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFoundException if no record returned from repository
	 * @see com.cg.healthservice.service.DiagnosticCenterService#searchById(int)
	 */
	@Override
	public DiagnosticCenter searchById(int id) {
		DiagnosticCenter diagnosticCenter=diagnosticCenterDao.findById(id);
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("DiagnosticService searchById(int) is executed!");
		}
		if(diagnosticCenter==null) {
			HealthServiceController.logger.error("Id not valid "+new NoDiagnosticCenterFoundException());
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		}
		return diagnosticCenter;
	}

	/* @author sulekha
	 * last modified-25/05/2019
	 * interacting with repository to get the diagnosticCenter records
	 * @return List<DiagnosticCenter>
	 * @see com.cg.healthservice.service.DiagnosticCenterService#getAlldiagnosticecenter()
	 */
	@Override
	public List<DiagnosticCenter> getAllDiagnosticCenter() {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("DiagnosticService getalldiagnosticCenter() is executed!");
		}
		return diagnosticCenterDao.findAll();
	}

}
