package com.cg.healthservice.exception;

public class InsertionFailedException extends RuntimeException {

	public InsertionFailedException() {
		super();
	}

	public InsertionFailedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InsertionFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public InsertionFailedException(String message) {
		super(message);
	}

	public InsertionFailedException(Throwable cause) {
		super(cause);
	}

	
}
