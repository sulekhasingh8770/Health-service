package com.cg.healthservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.healthservice.dto.DiagnosticCenter;

/**
 * @author sulekha
 * interface used for interact database to perform curd operation on DiagnosticCenter
 * 
 */
public interface DiagnosticCenterDao extends JpaRepository<DiagnosticCenter, Integer> {

	/* @sulekha
	 * last modified- 25/05/2019
	 * @param java.lang.String
	 * @return List<DiagnosticCenter>
	 * 
	 * 	*/
	public List<DiagnosticCenter> findByLocation(String location);


	/* @sulekha
	 * last modified- 25/05/2019
	 * retrieve the record from DB based on test name
	 * @param name String
	 * @return List<DiagnosticCenter>
	 * 
	 */
	@Query("select d from DiagnosticCenter d, in(d.tests) t where t.name= :name")
	public List<DiagnosticCenter> findByTest(String name);


	/* @sulekha
	 * retrieve the record from Db based by id
	 * @param id int
	 * @return DiagnosticCenter
	 */
	public DiagnosticCenter findById(int id);
}
