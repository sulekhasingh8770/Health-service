package com.cg.healthservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.healthservice.dto.Appointment;

/**
 * @author sulekha
 * interface used for perform curd operation on appointment class
 */
public interface AppointmentDao extends JpaRepository<Appointment, Integer> {

}
