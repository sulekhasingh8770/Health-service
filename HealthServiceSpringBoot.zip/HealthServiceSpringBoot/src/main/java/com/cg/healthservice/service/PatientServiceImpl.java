package com.cg.healthservice.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dao.PatientDao;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.NameNotFoundException;


/**
 * @author sulekha
 * class used to perform business logic on object and interact with PatientRepository to perform curd operation
 */
@Service("patientService")
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientDao patientdao;
	static int id=100;
	

	/* @author sulekha
	 * interact patientRepository to persist patient object
	 * @param patient com.cg.helathservice.dto.Patient
	 * @return com.cg.helathservice.dto.Patient
	 * @see com.cg.healthservice.service.PatientService#addPatient(com.cg.healthservice.dto.Patient)
	 */
	@Override
	public Patient addPatient(Patient patient) {
		patient.setId(id);
		id++;
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientService addPatient(Patient) is executed!");
			HealthServiceController.logger.debug(" Id "+id+" set to patient object");
		}
		return patientdao.save(patient);
	}

	/* @author sulekha
	 * interact with PatientRepository to retrieve the records using patient name
	 * @param name java.lang.String
	 * @return List<patient>
	 * @throw com.cg.healthservice.exception.NameNotFoundException if data not found
	 * @see com.cg.healthservice.service.PatientService#searchByName(java.lang.String)
	 */
	@Override
	public List<Patient> searchByName(String name) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientService searchByName(String) is executed!");
		}
		List<Patient> patients=patientdao.findByName(name);
		if(patients.isEmpty()) {
			HealthServiceController.logger.error(new NameNotFoundException());
			throw new NameNotFoundException("Name Not Found");
		}
		return patients;
	}

	/* @author sulekha
	 * interact with PatientRepository to retrieve the records using patient id
	 * @param id int
	 * @return Patient
	 * @throw com.cg.healthservice.exception.IdNotFoundException if data not found
	 * @see com.cg.healthservice.service.PatientService#searchById(int)
	 */
	@Override
	public Patient searchById(int id) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientService searchById(int) is executed!");
		}
		Patient patient=patientdao.findById(id);
		System.out.println(patient);
		if(patient==null) {
			HealthServiceController.logger.error(new IdNotFoundException());
			throw new IdNotFoundException("Given Id is not found");
		}
		return patient;
	}

	/* @author sulekha
	 * interact with PatientRepository to retrieve the records using patient id
	 * @return Patient
	 * @see com.cg.healthservice.service.PatientService#getAllPatient()
	 */
	@Override
	public List<Patient> getAllPatient() {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientService getAllPatient() is executed!");
		}
		return patientdao.findAll();
	}

}
