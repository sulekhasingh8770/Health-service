package com.cg.healthservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.healthservice.dto.Patient;

/**
 * @author sulekha
 * interface used for interact to DB to perform CURD operation
 * @extends JPARepository
 */
public interface PatientDao extends JpaRepository<Patient, Integer> {

	/* @sulekha
	 * retrieve record by using patient name
	 * @param name java.lang.String
	 * @return List<Patient>
	 * 
	 * 	*/
	public List<Patient> findByName(String name);
	
	/* @sulekha
	 * retrieve record by using primary key
	 * @param id int
	 * @return Patient
	 * @see com.cg.healthservice.dao.PatientRepository#findById(int)
	 * 
	 * 	*/
	public Patient findById(int id);

}
