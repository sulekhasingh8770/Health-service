package com.cg.healthservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author sulekha
 * class for configure application as SpringbootApplication
 *
 */
@SpringBootApplication
@ComponentScan("com.cg.healthservice")
public class HealthServiceSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthServiceSpringBootApplication.class, args);
		System.out.println("Health Service Started....");
	}

}
