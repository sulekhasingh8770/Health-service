package com.cg.healthservice.service;

import java.util.List;
import java.util.Optional;

import com.cg.healthservice.dto.DiagnosticCenter;

/**
 * @author sulekha
 * last modified- 25/05/2019
 * 
 */
public interface DiagnosticCenterService {

	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter);
	public List<DiagnosticCenter> searchByLocation(String location);
	public List<DiagnosticCenter> searchByTest(String name);
	public DiagnosticCenter searchById(int id);
	public List<DiagnosticCenter> getAllDiagnosticCenter();
}
