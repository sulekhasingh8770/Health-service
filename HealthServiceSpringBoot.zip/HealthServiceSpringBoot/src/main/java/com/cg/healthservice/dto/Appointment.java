package com.cg.healthservice.dto;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 * @author sulekha
 * model class to store appointment details int id, Patient patient, DiagnosticCenter  diagnosticCenter
 */
@Entity
public class Appointment {

	@Id
	private int id;
	@OneToOne(cascade=CascadeType.MERGE)
	private DiagnosticCenter diagnosticCenter;
	@OneToOne(cascade=CascadeType.MERGE)
	private Patient patient;
	@Column(name="appointment_date", columnDefinition="Date")
	private LocalDate date;
	
	public Appointment() {
		super();
	}

	public Appointment(int id, DiagnosticCenter diagnosticCenter, Patient patient, LocalDate date) {
		super();
		this.id = id;
		this.diagnosticCenter = diagnosticCenter;
		this.patient = patient;
		this.date = date;
	}
	
	public Appointment(DiagnosticCenter diagnosticCenter, Patient patient, LocalDate date) {
		super();
		this.diagnosticCenter = diagnosticCenter;
		this.patient = patient;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public DiagnosticCenter getDiagnosticCenter() {
		return diagnosticCenter;
	}

	public void setDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		this.diagnosticCenter = diagnosticCenter;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", diagnosticCenter=" + diagnosticCenter + ", patient=" + patient + ", date="
				+ date + "]";
	}
	
}
