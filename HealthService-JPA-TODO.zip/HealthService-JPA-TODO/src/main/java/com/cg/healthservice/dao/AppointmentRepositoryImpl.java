package com.cg.healthservice.dao;


import javax.persistence.EntityManager;
import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.util.DBUtil;

public class AppointmentRepositoryImpl implements AppointmentRepository {

	public Appointment save(Appointment appointment) {
		EntityManager em=DBUtil.entityManager;
		em.getTransaction().begin();
		em.persist(appointment);
		em.getTransaction().commit();
		return appointment;
	}

	

}
