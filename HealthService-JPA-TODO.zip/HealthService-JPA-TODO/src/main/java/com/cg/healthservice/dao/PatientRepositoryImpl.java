package com.cg.healthservice.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class PatientRepositoryImpl implements PatientRepository {

	
	public Patient save(Patient patient) {
		EntityManager em=DBUtil.entityManager;
		em.getTransaction().begin();
		em.persist(patient);
		em.getTransaction().commit();
		em.close();
		return patient;
	}

	public List<Patient> findByName(String name) {
		EntityManager em=DBUtil.entityManager;
		Query query=em.createQuery(DBQuery.FIND_BY_NAME_QUERY);
		query.setParameter("name", name);
		em.close();
		return query.getResultList();
	}

	public Patient findById(int id) {
		return DBUtil.entityManager.find(Patient.class, id);
	}
	
}
