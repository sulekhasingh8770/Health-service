package com.cg.healthservice.util;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@SuppressWarnings("UnusedDeclaration")
@Converter(autoApply = true)
public class LocalDateConverter implements AttributeConverter<LocalDate, Date> {

	public java.sql.Date convertToDatabaseColumn(LocalDate attribute) {
		return attribute == null ? null : java.sql.Date.valueOf(attribute);
	}
	public java.time.LocalDate convertToEntityAttribute(Date dbData) {
		return dbData == null ? null : dbData.toLocalDate();
	}
}

