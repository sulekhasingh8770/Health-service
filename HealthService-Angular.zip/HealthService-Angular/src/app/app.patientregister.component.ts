import { Component } from "@angular/core";
import { Patient } from "./app.patient";
import { PatientService } from "./app.patientservice";
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";



@Component({
    selector: 'patient-app',
    templateUrl: 'app.patientregister.html'
})

export class PatientRegister{

    model:any={};
    registerForm = this.formBuilder.group({
        name: ['', [Validators.required, Validators.minLength(4)]],
        contact: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10),Validators.pattern("[0-9]{10}")]],
        email: ['', [Validators.required, Validators.email]],
        address: ['', Validators.required]
    });

    constructor(private service: PatientService,private formBuilder: FormBuilder){}
    add(){
        // this.submitted=true;
        // console.log(this.registerForm.value.name);
        
        // if (this.registerForm.invalid) {
        //          return;
        // }
        
        this.model.name=this.registerForm.value.name;
        this.model.contact=this.registerForm.value.contact;
        this.model.email=this.registerForm.value.email;
        this.model.address=this.registerForm.value.address;
        console.log(this.model.name);
         this.service.addPatient(this.model).subscribe((data=>console.log(data)))
             alert("Added Succesfully");
            this.model.name=" ";
            this.model.contact=" ";
            this.model.email=" ";
            this.model.address=" ";
    }
}