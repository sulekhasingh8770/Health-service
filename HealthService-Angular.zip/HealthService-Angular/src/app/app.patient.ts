export class Patient{
    id: number;
    name:string;
    address:string;
    contact:number;
    email:string;
}