import { Component } from "@angular/core";
import { DiagnosticCenterService } from './app.diagnosticservice';
import { DiagnosticCenter } from './app.diagnostic';
import { error } from "@angular/compiler/src/util";

@Component({
    selector: 'search-location',
    templateUrl: 'app.searchbylocation.html'
})
export class SearchDiagnosticByLocationComponent{

    p: number=1;
    errorMessage:any;
    location:string;
    diagnostics: DiagnosticCenter[]=[];
    error: string;
    constructor(private service: DiagnosticCenterService){

    }


    searchByLocation(){
        this.error="";
         this.service.searchByLocation(this.location).subscribe((data:DiagnosticCenter[])=>
                                                                this.diagnostics=data,
                                                                error => this.error = error
                                                                );
        this.location="";
    }
}