﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { PatientComponent } from './app.patientcomponent';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { SearchPatientComponent } from './app.searchpatient';
import { DiagnosticCenterComponent } from './app.diagnosticcomponent';
import { AppointmentComponent } from './app.appointmentcomponent';
import { SearchDiagnosticByLocationComponent } from './app.searchdiagnosticcomponent';
import { SearchDiagnosticByTestComponent } from './app.searchDiagnosticbytest';
import { TestComponent } from './app.testcomponent';
import { ReactiveFormsModule } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination';
import { PatientRegister } from './app.patientregister.component';

const route: Routes=[
    { path: 'register', component: PatientRegister },
    { path: 'addPatient', component: PatientComponent    },
    { path: 'addDiagnostic', component: DiagnosticCenterComponent   },
    { path: 'addAppointment', component: AppointmentComponent    },
    { path: 'searchPatient', component: SearchPatientComponent   },
    { path: 'addDiagnostic/addTest', component: TestComponent   },
    { path: './addTest', component: TestComponent },
    { path: 'searchDiagnosticByLocation', component: SearchDiagnosticByLocationComponent   },
    { path: 'searchDiagnosticByTest', component: SearchDiagnosticByTestComponent   },
];
@NgModule({
    imports: [
        BrowserModule,
        FormsModule ,
        RouterModule.forRoot(route),
        HttpClientModule,
        ReactiveFormsModule,
        NgxPaginationModule
        
    ],
    declarations: [
        AppComponent, PatientComponent, DiagnosticCenterComponent, AppointmentComponent, SearchPatientComponent,
        SearchDiagnosticByLocationComponent, SearchDiagnosticByTestComponent, TestComponent, PatientRegister
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }