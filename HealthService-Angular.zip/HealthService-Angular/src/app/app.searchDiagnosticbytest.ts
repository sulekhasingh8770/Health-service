import { Component } from "@angular/core";
import { DiagnosticCenterService } from "./app.diagnosticservice";
import { DiagnosticCenter } from './app.diagnostic';

@Component({
    selector: 'search-test',
    templateUrl: 'app.searchbytest.html'
})
export class SearchDiagnosticByTestComponent{

    p:number=1;
    test:string;
    error: string;
    diagnostics: DiagnosticCenter[];
    constructor(private service: DiagnosticCenterService){}

    searchByTest(){
        this.error="";
        this.service.searchByTest(this.test).subscribe((data:DiagnosticCenter[])=>this.diagnostics=data,
                                                            error => this.error = error);
        this.test="";
    }
}