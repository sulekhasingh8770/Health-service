export class Test{
    name:string;
    cost:number;
}