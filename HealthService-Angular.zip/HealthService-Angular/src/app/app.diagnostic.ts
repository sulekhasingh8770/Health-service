import { Test } from "./app.test";

export class DiagnosticCenter{
    id:number;
    name: string;
    location: string;
    contact: number;
    tests:Test[];
}