/**
 
 This class is written to establish a connection with database. 
*/
package com.cg.currypoint.util;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class DbUtil {
	
	public static EntityManager entityManager = Persistence.createEntityManagerFactory("currypoint").createEntityManager();
	
}
	

