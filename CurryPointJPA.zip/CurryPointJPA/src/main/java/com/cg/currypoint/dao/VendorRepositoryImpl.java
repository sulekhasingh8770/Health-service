
/**
 
 This class is written to retrieval data from data source. 
 This program contains three methods which performs adding vendor details, findby given location and findby by vendor name.
*/

package com.cg.currypoint.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.currypoint.dto.Vendor;
import com.cg.currypoint.util.DBQuery;
import com.cg.currypoint.util.DbUtil;

public class VendorRepositoryImpl implements VendorRepository {

	public Vendor save(Vendor vendor) {
		EntityManager em=DbUtil.entityManager;
		em.getTransaction().begin();
		em.persist(vendor);
		em.getTransaction().commit();
		//em.close();
		return vendor;
	}

	public List<Vendor> findByLocation(String city) {
		EntityManager em=DbUtil.entityManager;
		Query query=em.createQuery(DBQuery.FIND_BY_LOCATION);
		query.setParameter("city", city);
		return query.getResultList();
	}

	public List<Vendor> findByName(String name) {
		EntityManager em=DbUtil.entityManager;
		Query query=em.createQuery(DBQuery.FIND_BY_NAME);
		query.setParameter("name", name);
		return query.getResultList();
	}
	
}
