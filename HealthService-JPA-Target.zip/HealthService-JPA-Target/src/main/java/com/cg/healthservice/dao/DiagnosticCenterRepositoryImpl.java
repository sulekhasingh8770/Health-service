package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		EntityManager em=DBUtil.begin();
//		em.getTransaction().begin();
		em.persist(diagnosticCenter);
		DBUtil.commit();
//		em.getTransaction().commit();
		em.close();
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
		EntityManager em=DBUtil.begin();
		Query query=em.createQuery(DBQuery.FIND_BY_LOCATION);
		query.setParameter("location", location);
		DBUtil.commit();
//		em.close();
		return query.getResultList();
	}

	public List<DiagnosticCenter> findByTest(String name) {
		EntityManager em=DBUtil.begin();
		Query query=em.createQuery(DBQuery.FIND_BY_TEST);
		query.setParameter("testName", name);
		DBUtil.commit();
//		em.close();
		return query.getResultList();
	}

	public DiagnosticCenter findById(int id) {
		return DBUtil.entityManager.find(DiagnosticCenter.class, id);
	}

		
}
