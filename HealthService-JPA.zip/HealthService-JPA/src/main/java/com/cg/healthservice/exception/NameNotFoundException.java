package com.cg.healthservice.exception;

public class NameNotFoundException extends RuntimeException {

	public NameNotFoundException() {
		super();
	}

	public NameNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NameNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public NameNotFoundException(String message) {
		super(message);
	}

	public NameNotFoundException(Throwable cause) {
		super(cause);
	}

}
