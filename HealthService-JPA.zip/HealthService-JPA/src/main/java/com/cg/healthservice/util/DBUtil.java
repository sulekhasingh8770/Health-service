package com.cg.healthservice.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.cg.healthservice.exception.ConnectionException;


/**
 * @author sulekha
 *
 * class used to interact with the persistence context.
 */
public class DBUtil {

	public static EntityManagerFactory factory=Persistence.createEntityManagerFactory("healthservice");
	public static EntityManager entityManager;
	public static EntityTransaction tx;

	/*
	 *  used to create instance of EntityManager
	 */
	public static EntityManager begin(){
		try {
			EntityManager entityManager=factory.createEntityManager();
			tx=entityManager.getTransaction();
			tx.begin();
			return entityManager;
		}catch(Exception e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
	}
	/*
	 * used to commit the transaction and close EntityManager
	 */
	public static void commit() {
		tx.commit();
		if(entityManager!=null)
			entityManager.close();
	}
}
