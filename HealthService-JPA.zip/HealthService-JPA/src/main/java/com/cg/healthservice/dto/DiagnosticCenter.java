package com.cg.healthservice.dto;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class DiagnosticCenter {

	@Id
	private int id;
	private String name;
	private String location;
	private BigInteger contact;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="dignostic_id")
	private List<Test> tests;
	
	public DiagnosticCenter() {
		super();
	}

	public DiagnosticCenter(int id, String name, String location, BigInteger contact, List<Test> tests) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.contact = contact;
		this.tests = tests;
	}
	
	public DiagnosticCenter(String name, String location, BigInteger contact, List<Test> tests) {
		super();
		this.name = name;
		this.location = location;
		this.contact = contact;
		this.tests = tests;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public BigInteger getContact() {
		return contact;
	}
	public void setContact(BigInteger contact) {
		this.contact = contact;
	}
	public List<Test> getTests() {
		return tests;
	}
	public void setTests(List<Test> tests) {
		this.tests = tests;
	}
	@Override
	public String toString() {
		return "DiagnosticCenter [id=" + id + ", name=" + name + ", location=" + location + ", contact=" + contact
				+ ", tests=" + tests + "]";
	}
	
}
