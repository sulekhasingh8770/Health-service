package com.cg.healthservice.util;


/**
 * @author sulekha
 * interface used for query 
 */
public interface DBQuery {

	public static final String FIND_BY_NAME_QUERY="select p from Patient p where p.name= :name";
	public static final String FIND_BY_LOCATION="select d from DiagnosticCenter d where d.location= :location";
	public static final String FIND_BY_TEST="select d from DiagnosticCenter d, in(d.tests) t where t.name= :testName";
}
