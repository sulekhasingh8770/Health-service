package com.cg.healthservice.util;

public interface DBQuery {

	public static final String INSERT_QUERY="insert into patient values(?,?,?,?,?)";
	public static final String FIND_BY_NAME_QUERY="SELECT * FROM patient WHERE pname=?";
	public static final String FIND_BY_ID_QUERY="SELECT * FROM patient WHERE pid=?";
	public static final String Diagnostic_INSERT_QUERY="insert into diagnostic_center values(?,?,?,?)";
	public static final String FIND_BY_LOCATION="select * from diagnostic_center where dlocation=?";
	public static final String FIND_BY_TEST="select d.did, d.dname,d.dlocation,d.dcontact, t.tid, t.tname,t.tcost from diagnostic_center d inner join test t on t.diagnostic_id=d.did where t.tname=?";
	public static final String Diagnostic_FIND_BY_ID="select * from diagnostic_center where did=?";
	public static final String Appointment_INSERT_QUERY="insert into appointment values(?,?,?,?)";
}
