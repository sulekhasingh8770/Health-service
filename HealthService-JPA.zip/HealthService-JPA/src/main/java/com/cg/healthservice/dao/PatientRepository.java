package com.cg.healthservice.dao;

import java.util.List;

import com.cg.healthservice.dto.Patient;

public interface PatientRepository {

	public Patient save(Patient patient);
	public List<Patient> findByName(String name);
	public Patient findById(int id);
}
