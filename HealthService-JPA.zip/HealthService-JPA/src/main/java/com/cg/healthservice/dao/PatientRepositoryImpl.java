package com.cg.healthservice.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.util.DBUtil;

public class PatientRepositoryImpl implements PatientRepository {

	EntityManager em;
	
	
	public PatientRepositoryImpl() {
		em=DBUtil.entityManager;
	}

	public Patient save(Patient patient) {
		em.getTransaction().begin();
		em.persist(patient);
		em.getTransaction().commit();
		return patient;
	}

	public List<Patient> findByName(String name) {
		Query query=em.createQuery("select p from Patient p where p.name= :name");
		query.setParameter("name", name);
		return query.getResultList();
	}

	public Patient findById(int id) {
		Query query=em.createQuery("SELECT p FROM Patient p WHERE p.id= :id");
		query.setParameter("id", id);
		try {
			System.out.println(query.getSingleResult());
			return (Patient) query.getSingleResult();
		}catch(NoResultException e) {
			throw new IdNotFoundException("Invalid Id..");
		}
		
//		return em.find(Patient.class, id);
	}
	
}
