package com.cg.healthservice.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 * class used to interact with DBUtil and perform saving and retrieving data
 */
public class PatientRepositoryImpl implements PatientRepository {
	
	/*
	 * make patient instance managed and persist
	 * @param patient com.cg.healthservice.dto.Patient
	 * @return patient
	 * @throw ConnectionException if unable to persist
	 * @see com.cg.healthservice.dao.PatientRepository#save(com.cg.helathservice.dto.Patient)
	 * 
	 * 	*/
	public Patient save(Patient patient) {
		try {
			EntityManager em=DBUtil.begin();
			em.persist(patient);
			DBUtil.commit();	
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred in connection..");
		}
		return patient;
	}

	/*
	 * retrieve record by using patient name
	 * @param name java.lang.String
	 * @return List<Patient>
	 * @throw ConnectionException if unable to retrieve
	 * @see com.cg.healthservice.dao.PatientRepository#findByName(java.lang.String)
	 * 
	 * 	*/
	public List<Patient> findByName(String name) {
		Query query;
		try {
			EntityManager em=DBUtil.begin();
			query=em.createQuery(DBQuery.FIND_BY_NAME_QUERY);
			query.setParameter("name", name);
			DBUtil.commit();
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred in connection..");
		}
		return query.getResultList();
	}

	/*
	 * retrieve record by using primary key
	 * @param id int
	 * @return List<Patient>
	 * @see com.cg.healthservice.dao.PatientRepository#findById(int)
	 * 
	 * 	*/
	public Patient findById(int id) {
		return DBUtil.begin().find(Patient.class, id);
	}
	
}
