package com.cg.healthservice.service;

import com.cg.healthservice.dao.AppointmentRepository;
import com.cg.healthservice.dao.AppointmentRepositoryImpl;
import com.cg.healthservice.dto.Appointment;

public class AppointmentServiceImpl implements AppointmentService {

	AppointmentRepository dao;
	static int id=500;
	public AppointmentServiceImpl() {
		dao=new AppointmentRepositoryImpl();
	}

	public Appointment addAppointment(Appointment appointment) {
		appointment.setId(id);
		id++;
		return dao.save(appointment);
	}
}
