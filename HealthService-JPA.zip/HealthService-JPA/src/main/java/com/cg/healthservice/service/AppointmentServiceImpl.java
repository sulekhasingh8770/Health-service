package com.cg.healthservice.service;

import com.cg.healthservice.dao.AppointmentRepository;
import com.cg.healthservice.dao.AppointmentRepositoryImpl;
import com.cg.healthservice.dto.Appointment;

/**
 * @author sulekha
 * class used to perform business logic and interact with AppointmentRepository
 * @see com.cg.healthservice.service.AppointmentService
 */
public class AppointmentServiceImpl implements AppointmentService {

	//generating id
	AppointmentRepository dao;
	static int id=500;
	public AppointmentServiceImpl() {
		dao=new AppointmentRepositoryImpl();
	}
	/*
	 * interact with AppointmnetRepository to persist appointment
	 * @param appointment com.cg.healthservice.dto.Appointment
	 * @return appointment
	 * @see com.cg.healthservice.service.AppointmentService#addAppointment(com.cg.healthservice.dto.Appointment)
	 */
	public Appointment addAppointment(Appointment appointment) {
		appointment.setId(id);
		id++;
		return dao.save(appointment);
	}
}
