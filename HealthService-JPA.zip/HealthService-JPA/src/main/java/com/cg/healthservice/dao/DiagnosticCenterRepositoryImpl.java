package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	EntityManager em;
	
	public DiagnosticCenterRepositoryImpl() {
		em=DBUtil.entityManager;
	}

	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
//		EntityManager em=DBUtil.entityManager;
		em.getTransaction().begin();
		em.persist(diagnosticCenter);
		em.getTransaction().commit();
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
//		EntityManager em=DBUtil.entityManager;
		Query query=em.createQuery("select d from DiagnosticCenter d where d.location= :location");
		query.setParameter("location", location);
		return query.getResultList();
	}

	public List<DiagnosticCenter> findByTest(String name) {
//		EntityManager em=DBUtil.entityManager;
		Query query=em.createQuery("select d from DiagnosticCenter d, in(d.tests) t where t.name= :testName");
		query.setParameter("testName", name);
		return query.getResultList();
	}

	public DiagnosticCenter findById(int id) {
//		EntityManager em=DBUtil.entityManager;
		DiagnosticCenter diagnosticCenter=em.find(DiagnosticCenter.class, id);
		return diagnosticCenter;
	}

		
}
