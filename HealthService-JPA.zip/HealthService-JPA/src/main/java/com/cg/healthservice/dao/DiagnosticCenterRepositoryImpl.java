package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		try{
			EntityManager em=DBUtil.begin();
			em.persist(diagnosticCenter);
			DBUtil.commit();	
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
		Query query;
		try {
		EntityManager em=DBUtil.begin();
		query=em.createQuery(DBQuery.FIND_BY_LOCATION);
		DBUtil.commit();
		query.setParameter("location", location);
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		return query.getResultList();
	}

	public List<DiagnosticCenter> findByTest(String name) {
		Query query;
		try {
			EntityManager em=DBUtil.begin();
			query=em.createQuery(DBQuery.FIND_BY_TEST);
			query.setParameter("testName", name);
			DBUtil.commit();
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		
		return query.getResultList();
	}

	public DiagnosticCenter findById(int id) {
		return DBUtil.begin().find(DiagnosticCenter.class, id);
	}

		
}
