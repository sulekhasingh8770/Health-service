package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 * 
 * class used to interact with DBUtil and perform save and retrieve operation
 *
 */
public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	/*
	 * save the diagnosticCenter
	 * @param diagnosticCenter DiagnosticCenter
	 * @return diagnostiCenter
	 * @throw ConnectionException if data not saved
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#save(com.cg.healthservice.dto.DiagnosticCenter)
	 * 
	 * 	*/
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		try{
			EntityManager em=DBUtil.begin();
			em.persist(diagnosticCenter);
			DBUtil.commit();	
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		return diagnosticCenter;
	}

	/*
	 * retrieve the record from Db based on location
	 * @param location String
	 * @return List<DiagnosticCenter>
	 * @throw ConnectionException if unable to retrieve data
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByLocation(java.lang.String)
	 */
	public List<DiagnosticCenter> findByLocation(String location) {
		Query query;
		try {
		EntityManager em=DBUtil.begin();
		query=em.createQuery(DBQuery.FIND_BY_LOCATION);
		DBUtil.commit();
		query.setParameter("location", location);
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		return query.getResultList();
	}
	/*
	 * retrieve the record from Db based on test name
	 * @param name String
	 * @return List<DiagnosticCenter>
	 * @throw ConnectionException if unable to retrieve data
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByTest(java.lang.String)
	 */
	public List<DiagnosticCenter> findByTest(String name) {
		Query query;
		try {
			EntityManager em=DBUtil.begin();
			query=em.createQuery(DBQuery.FIND_BY_TEST);
			query.setParameter("testName", name);
			DBUtil.commit();
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occurred during connection...");
		}
		
		return query.getResultList();
	}

	/*
	 * retrieve the record by primary key
	 * @param id int
	 * @return DiagnosticCenter
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findById(int)
	 */
	public DiagnosticCenter findById(int id) {
		return DBUtil.begin().find(DiagnosticCenter.class, id);
	}

		
}
