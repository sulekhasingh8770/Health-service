package com.cg.healthservice.dao;


import javax.persistence.EntityManager;
import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 *
 * class used to interact with DBUtil
 * this class perform operation regarding appointment class.
 * 
 */
public class AppointmentRepositoryImpl implements AppointmentRepository {

	/*
	 * make an appointment object to managed and persist
	 * method save
	 * @param appointment Appointment
	 * @return appointment
	 * @throws ConnectionException
	 * @see com.cg.healthservice.dao.AppointmentRepository#save(com.cg.healthservice.dto.Appointment)
	 * 
	 * 	*/
	public Appointment save(Appointment appointment) {
		try {
		EntityManager em=DBUtil.begin();
		em.persist(appointment);
		DBUtil.commit();
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occured in connection");
		}
		return appointment;
	}

	

}
