package com.cg.healthservice.dao;


import javax.persistence.EntityManager;
import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.util.DBUtil;

public class AppointmentRepositoryImpl implements AppointmentRepository {

	public Appointment save(Appointment appointment) {
		try {
		EntityManager em=DBUtil.begin();
		em.persist(appointment);
		DBUtil.commit();
		}catch(ConnectionException e) {
			throw new ConnectionException("Problem occured in connection");
		}
		return appointment;
	}

	

}
