package com.cg.healthservice.service;

import java.util.List;


import com.cg.healthservice.dao.PatientRepository;
import com.cg.healthservice.dao.PatientRepositoryImpl;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.NameNotFoundException;

public class PatientServiceImpl implements PatientService {

	PatientRepository dao;
	static int id=100;
	public PatientServiceImpl() {
		dao=new PatientRepositoryImpl();
	}

	public Patient addPatient(Patient patient) {
		patient.setId(id);
		id++;
		return dao.save(patient);
	}

	public List<Patient> searchByName(String name) {
		List<Patient> patients=dao.findByName(name);
		if(patients.isEmpty())
			throw new NameNotFoundException("Name Not Found");
		return patients;
	}

	public Patient searchById(int id) {
		Patient patient=dao.findById(id);
		/*if(patient==null)
			throw new IdNotFoundException("Given Id is not valid");*/
		return patient;
	}

}
