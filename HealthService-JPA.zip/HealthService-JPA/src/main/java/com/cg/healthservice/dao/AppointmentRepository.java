package com.cg.healthservice.dao;


import com.cg.healthservice.dto.Appointment;

public interface AppointmentRepository {

	
	public Appointment save(Appointment appointment);
}
