package com.cg.assignment.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.assignment.dto.Author;
import com.cg.assignment.dto.Book;

public class BookAuthorDaoImpl implements BookAuthorDao {

	EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpa_assignment");
	EntityManager em=factory.createEntityManager();
	
	public List<Book> findAll() {
		Query query=em.createQuery("Select book From Book book",Book.class);
		return query.getResultList();
	}

	public List<Book> findByName(String name) {
		Query query=em.createQuery("Select a.books from Author a where a.name= :name");
		query.setParameter("name", name);
		return query.getResultList();
	}

	public List<Book> findByPrice(double min, double max) {
		Query query=em.createQuery("Select b from Book b where price BETWEEN :min AND :max");
		query.setParameter("min", min);
		query.setParameter("max", max);
		return query.getResultList();
	}

	public Author findByIsbn(int isbn) {
		Query query=em.createQuery("select a from Author a, in(a.books) b where b.isbn= :isbn");
		query.setParameter("isbn", isbn);
		return (Author) query.getSingleResult();
	}

}
