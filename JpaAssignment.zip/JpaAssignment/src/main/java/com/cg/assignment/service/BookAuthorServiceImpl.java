package com.cg.assignment.service;

import java.util.List;

import com.cg.assignment.dao.BookAuthorDao;
import com.cg.assignment.dao.BookAuthorDaoImpl;
import com.cg.assignment.dto.Author;
import com.cg.assignment.dto.Book;

public class BookAuthorServiceImpl implements BookAuthorService {

	BookAuthorDao dao;
	
	
	public BookAuthorServiceImpl() {
		dao=new BookAuthorDaoImpl();
	}

	public List<Book> findAll() {
		return dao.findAll();
	}

	public List<Book> findByName(String name) {
		return dao.findByName(name);
	}

	public List<Book> findByPrice(double min, double max) {
		return dao.findByPrice(min, max);
	}

	public Author findByIsbn(int isbn) {
		return dao.findByIsbn(isbn);
	}

}
