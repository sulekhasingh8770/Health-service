package com.cg.assignment.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.assignment.dto.Book;
import com.cg.assignment.service.BookAuthorService;
import com.cg.assignment.service.BookAuthorServiceImpl;

public class BookAuthorMain {

	public static void main(String[] args) {

		BookAuthorService service=new BookAuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		List<Book> books=new ArrayList<Book>();
		
		System.out.println("--------show all books---------------");
		books=service.findAll();
		for(Book b: books)
			System.out.println(b);
				
		System.out.println("----------Show book by author name-------");
		System.out.println("Enter author name---------");
		String name=sc.next();
		books=service.findByName(name);
		for(Book b: books)
			System.out.println(b);
		
		System.out.println("---------show books by price---------");
		System.out.println("Enter the min price: ");
		double min=sc.nextDouble();
		System.out.println("Enter max price: ");
		double max=sc.nextDouble();
		books=service.findByPrice(min, max);
		for(Book b: books)
			System.out.println(b);
		
		System.out.println("----------Find auhtor by book no.---------");
		System.out.println("Enter isbn: ");
		int isbn=sc.nextInt();
		System.out.println(service.findByIsbn(isbn));
		
	}

}
