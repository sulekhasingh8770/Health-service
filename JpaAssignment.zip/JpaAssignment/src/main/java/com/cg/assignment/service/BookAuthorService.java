package com.cg.assignment.service;

import java.util.List;

import com.cg.assignment.dto.Author;
import com.cg.assignment.dto.Book;

public interface BookAuthorService {

	public List<Book> findAll();
	public List<Book> findByName(String name);
	public List<Book> findByPrice(double min,double max);
	public Author findByIsbn(int isbn);
}
