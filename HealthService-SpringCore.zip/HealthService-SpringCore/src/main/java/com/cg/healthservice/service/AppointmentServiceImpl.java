package com.cg.healthservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.dao.AppointmentRepository;
import com.cg.healthservice.dao.AppointmentRepositoryImpl;
import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.ui.HealthService;

/**
 * @author sulekha
 * class used to perform business logic and interact with AppointmentRepository
 * @see com.cg.healthservice.service.AppointmentService
 */
@Service("appointmentService")
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppointmentRepository dao;
	//generating id
	static int id=500;
	
	/*
	 * interact with AppointmnetRepository to persist appointment
	 * @param appointment com.cg.healthservice.dto.Appointment
	 * @return appointment
	 * @see com.cg.healthservice.service.AppointmentService#addAppointment(com.cg.healthservice.dto.Appointment)
	 */
	public Appointment addAppointment(Appointment appointment) {
		appointment.setId(id);
		id++;
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addAppointmentService addAppointment(Appointment) is executed!");
			HealthService.logger.debug(" Id "+id+" set to Appointment object");
		}
		return dao.save(appointment);
	}
}
