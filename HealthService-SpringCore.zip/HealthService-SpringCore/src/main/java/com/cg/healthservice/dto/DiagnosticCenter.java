package com.cg.healthservice.dto;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class DiagnosticCenter {

	private int id;
	private String name;
	private String location;
	private BigInteger contact;
	private List<Test> tests;
	
	public DiagnosticCenter() {
		super();
	}

	public DiagnosticCenter(int id, String name, String location, BigInteger contact, List<Test> tests) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.contact = contact;
		this.tests = tests;
	}
	
	
	public DiagnosticCenter(String name, String location, BigInteger contact, List<Test> tests) {
		super();
		this.name = name;
		this.location = location;
		this.contact = contact;
		this.tests = tests;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public BigInteger getContact() {
		return contact;
	}
	public void setContact(BigInteger contact) {
		this.contact = contact;
	}
	public List<Test> getTests() {
		return tests;
	}
	public void setTests(List<Test> tests) {
		this.tests = tests;
	}
	@Override
	public String toString() {
		return "DiagnosticCenter [id=" + id + ", name=" + name + ", location=" + location + ", contact=" + contact
				+ ", tests=" + tests + "]";
	}
	
}
