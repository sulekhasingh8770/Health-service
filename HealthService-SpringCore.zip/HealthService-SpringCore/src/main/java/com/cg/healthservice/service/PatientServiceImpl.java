package com.cg.healthservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.dao.PatientRepository;
import com.cg.healthservice.dao.PatientRepositoryImpl;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.NameNotFoundException;
import com.cg.healthservice.ui.HealthService;

/**
 * @author sulekha
 * class used to perform business logic on object and interact with PatientRepository to perform curd operation
 */
@Service("patientService")
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository dao;
	
	//generating id value
	static int id=100;

	/*
	 * interact patientRepository to persist patient object
	 * @param patient com.cg.helathservice.dto.Patient
	 * @return com.cg.helathservice.dto.Patient
	 * @see com.cg.healthservice.service.PatientService#addPatient(com.cg.healthservice.dto.Patient)
	 */
	public Patient addPatient(Patient patient) {
		
		
		patient.setId(id);
		id++;
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addPatientService addPatient(Patient) is executed!");
			HealthService.logger.debug(" Id "+id+" set to patient object");
		}
		return dao.save(patient);
	}

	/*
	 * interact with PatientRepository to retrieve the records using patient name
	 * @param name java.lang.String
	 * @return List<patient>
	 * @throw com.cg.healthservice.exception.NameNotFoundException if data not found
	 * @see com.cg.healthservice.service.PatientService#searchByName(java.lang.String)
	 */
	public List<Patient> searchByName(String name) {
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addPatientService searchByName(String) is executed!");
		}
		List<Patient> patients=dao.findByName(name);
		if(patients.isEmpty()) {
			HealthService.logger.error(new NameNotFoundException());
			throw new NameNotFoundException("Name Not Found");
		}
			
		return patients;
	}

	/*
	 * interact with PatientRepository to retrieve the records using primary key id
	 * @param id int
	 * @return com.cg.healthService.dto.Patient
	 * com.cg.healthservice.exception.IdNotFoundException if data not found
	 * @see com.cg.healthservice.service.PatientService#searchById(int)
	 */
	public Patient searchById(int id) {
		Patient patient=dao.findById(id);
		if(patient==null) {
			HealthService.logger.error(new IdNotFoundException());
			throw new IdNotFoundException("Given Id is not valid");
		}
			
		return patient;
	}

}
