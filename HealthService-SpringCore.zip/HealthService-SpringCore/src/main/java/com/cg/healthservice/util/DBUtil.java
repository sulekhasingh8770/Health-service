package com.cg.healthservice.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.dto.Test;


/**
 * @author sulekha
 *
 * class act as a db.
 * will store all data inside list.
 */
@Repository
public class DBUtil {

	public static List<Patient> patients=new ArrayList<Patient>();
	public static List<Appointment> appointments=new ArrayList<Appointment>();
	public static List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
	public static List<Test> tests=new ArrayList<Test>();
}
