package com.cg.healthservice.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



/**
 * @author sulekha
 * configuration class of project
 *
 */
@Configuration
@ComponentScan("com.cg.healthservice")
public class AppConfig {

	
}
