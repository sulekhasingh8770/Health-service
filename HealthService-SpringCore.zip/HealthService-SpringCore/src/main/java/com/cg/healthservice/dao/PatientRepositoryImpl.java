package com.cg.healthservice.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.ui.HealthService;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 * class used to interact with DBUtil and perform saving and retrieving data
 */
@Repository("patientRepository")
public class PatientRepositoryImpl implements PatientRepository {
	
	/*
	 * make patient instance managed and persist
	 * @param patient com.cg.healthservice.dto.Patient
	 * @return patient
	 * @see com.cg.healthservice.dao.PatientRepository#save(com.cg.helathservice.dto.Patient)
	 * 
	 * 	*/
	public Patient save(Patient patient) {
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addPatientRepository save(patient) is executed!");
		}
		DBUtil.patients.add(patient);
		return patient;
	}

	/*
	 * retrieve record by using patient name
	 * @param name java.lang.String
	 * @return List<Patient>
	 * @see com.cg.healthservice.dao.PatientRepository#findByName(java.lang.String)
	 * 
	 * 	*/
	public List<Patient> findByName(String name) {
		List<Patient> pList=new ArrayList<Patient>();
		for(Patient p: DBUtil.patients)
			if(p.getName().equals(name)) {
				pList.add(p);
			}
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addPatientRepository findByName() is executed! patient list is returned");
		}
		return pList;
	}

	/*
	 * retrieve record by using primary key
	 * @param id int
	 * @return List<Patient>
	 * @see com.cg.healthservice.dao.PatientRepository#findById(int)
	 * 
	 * 	*/
	public Patient findById(int id) {
		if(HealthService.logger.isDebugEnabled()){
			HealthService.logger.debug("addPatientRepository findById() is executed!");
		}
		for(Patient p: DBUtil.patients)
			if(p.getId()==id)
				return p;
		return null;
	}
	
}
