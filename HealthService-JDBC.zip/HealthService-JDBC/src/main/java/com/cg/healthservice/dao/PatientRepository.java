package com.cg.healthservice.dao;

import java.util.List;

import com.cg.healthservice.dto.Patient;

public interface PatientRepository {

	public static final String INSERT_QUERY="insert into patient values(?,?,?,?,?)";
	public static final String FIND_BY_NAME_QUERY="SELECT * FROM patient WHERE pname=?";
	public static final String FIND_BY_ID_QUERY="SELECT * FROM patient WHERE pid=?";
	public Patient save(Patient patient);
	public List<Patient> findByName(String name);
	public Patient findById(int id);
}
