package com.cg.healthservice.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.exception.NameNotFoundException;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;
import com.cg.healthservice.service.AppointmentService;
import com.cg.healthservice.service.AppointmentServiceImpl;
import com.cg.healthservice.service.DiagnosticCenterService;
import com.cg.healthservice.service.DiagnosticCenterServiceImpl;
import com.cg.healthservice.service.PatientService;
import com.cg.healthservice.service.PatientServiceImpl;
import com.cg.healthservice.util.DBUtil;


public class HealthService {

	public static void main(String[] args) throws IOException {
		
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		PatientService service=new PatientServiceImpl();
		DiagnosticCenterService diagnosticCenterService=new DiagnosticCenterServiceImpl();
		AppointmentService appointmentService=new AppointmentServiceImpl();
		Scanner sc=new Scanner(System.in);
		Patient patient=null;
		Test test;
		DiagnosticCenter diagnosticCenter=null;
		Appointment appointment;
		List<Patient> patientList;
		List<DiagnosticCenter> diagnosticCenters;
		List<Test> tests;
		int id;
		String name=null;
		String address=null;
		BigInteger contact=null;
		String email=null;
		int choice;

		do {
			print();
			choice=sc.nextInt();
			switch (choice) {
			case 1:	//Insert patient details...
				System.out.println("Enter patient Name:");
				name=br.readLine();
				System.out.println("Enter Address: ");
				address=br.readLine();
				System.out.println("Enter contact: ");
				contact=sc.nextBigInteger();
				System.out.println("Enter email: ");
				email=sc.next();
				id=new Random().nextInt(200);	
				patient=new Patient(id, name, address, contact, email);
				try {
				System.out.println(service.addPatient(patient));
				}catch(InsertionFailedException e) {
					e.getMessage();
				}
				break;

			case 2:	//Insert diagnostic details..
				System.out.print("Enter diagnostic name: ");
				name=br.readLine();
				System.out.print("Enter Location: ");
				address=sc.next();
				System.out.print("Enter contact: ");
				contact=sc.nextBigInteger();
				tests=new ArrayList<Test>();
				do {
					System.out.print("Enter test id: ");
					int testId = sc.nextInt();
					System.out.print("Enter test name: ");
					String testName = br.readLine();
					System.out.print("Enter price: ");
					BigDecimal cost = sc.nextBigDecimal();
					test=new Test(testId, testName, cost);
					tests.add(test);
					System.out.println("Do you want to add more? ");
					System.out.println("Press 1 to continue/Press 2 for exit");
					choice=sc.nextInt();
				}while(choice!=2);
				id=new Random().nextInt(500);
				diagnosticCenter=new DiagnosticCenter(id, name, address, contact, tests);
				try {
					System.out.println(diagnosticCenterService.addDiagnosticCenter(diagnosticCenter));
				}catch(InsertionFailedException e) {
					e.getMessage();
				}

				break;

			case 3:	//Insert appointement details..
				System.out.print("Enter  patient id: ");
				id=sc.nextInt();
				System.out.print("Enter  diagnostic center id:");
				int diagnosticCenterId=sc.nextInt();
				System.out.print("Enter date(dd/MM/YY) for appointment: ");
				String date=sc.next();
				DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yy");
				LocalDate localDate=null;
				try {
					localDate=LocalDate.parse(date, formatter);
				}catch(Exception e) {
					System.out.println("Date format is invalid");
					break;
				}
				try {
					patient=service.searchById(id);
				}catch(IdNotFoundException e) {
					System.out.println(e.getMessage());
				}
				try {
					diagnosticCenter=diagnosticCenterService.searchById(diagnosticCenterId);
				}catch(NoDiagnosticCenterFoundException e) {
					System.out.println(e.getMessage());
				}
				if(patient!=null && diagnosticCenter!=null) {
					int appointmentId=new Random().nextInt(500);
					appointment=new Appointment(appointmentId, diagnosticCenter, patient,localDate);
					try {
					appointmentService.addAppointment(appointment);
					}catch(InsertionFailedException e) {
						e.getMessage();
					}
					System.out.println("Appointment Booked with "+diagnosticCenter.getName()+
							" on "+localDate+ " your appointment  id: "+appointmentId);
				}	
				break;

			case 4:	//Search patient info by giving name
				System.out.print("Enter name: ");
				name=br.readLine();
				try {
					if(name.isEmpty()) {
						System.out.println("please enter name..");
					}else {
						patientList=service.searchByName(name);
						for(Patient p: patientList)
							System.out.println(p);
					}
				}catch(NameNotFoundException e) {
					System.err.println(e.getMessage());
				}catch(ConnectionException e) {
					e.getMessage();
				}
				break;

			case 5:	//search diagnostic center by location
				System.out.print("Enter Location: ");
				address=sc.next();
				try {
					if(address.isEmpty()) {
						System.out.println("please enter location");
					}else {
						diagnosticCenters=diagnosticCenterService.searchByLocation(address);
						for(DiagnosticCenter d: diagnosticCenters) {
							System.out.println("id: "+d.getId()+" name: "+d.getName()+
									" location: "+d.getLocation()+" contact: "+d.getContact());
						}
					}
				}catch(NoDiagnosticCenterFoundException e) {
					System.out.println(e.getMessage());
				}catch(ConnectionException e) {
					e.getMessage();
				}
				break;

			case 6:	//search diagnostic center by giving test name
				System.out.println("Enter test name: ");
				name=br.readLine();
				try {
					diagnosticCenters= diagnosticCenterService.searchByTest(name);
					for(DiagnosticCenter d: diagnosticCenters)
						System.out.println(d);
				}catch(NoTestMatchingDiagnosticCenterFound e) {
					System.out.println(e.getMessage());
				}catch(ConnectionException e) {
					e.getMessage();
				}
				break;

			case 7:
				return;

			default:
				System.out.println("please enter any one of below options");
				print();
				break;
			}
		} while (choice!=7);
	}

	static void print() {
		System.out.println("What you want to do?");
		System.out.println("1. Add Patient");
		System.out.println("2. Add Diagnostic Center");
		System.out.println("3. Take appointment");
		System.out.println("4. Search PatientByName");
		System.out.println("5. Search DiagnosticCenterByLocation");
		System.out.println("6. Search DiagnosticCenterByTestName");
		System.out.println("7. Exit");
	}
}
