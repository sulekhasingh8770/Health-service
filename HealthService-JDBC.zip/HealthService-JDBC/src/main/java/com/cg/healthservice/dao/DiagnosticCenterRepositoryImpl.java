package com.cg.healthservice.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		try {
			//creating connection to DB
			conn=DBUtil.getConnection();
			//creating query...
			pstmt=conn.prepareStatement(DBQuery.DIAGNOSTIC_INSERT_QUERY);
			//converting java object to table row form
			pstmt.setInt(1, diagnosticCenter.getId());
			pstmt.setString(2, diagnosticCenter.getName());
			pstmt.setString(3, diagnosticCenter.getLocation());
			pstmt.setString(4,diagnosticCenter.getContact().toString());
			int i=pstmt.executeUpdate();
			for(Test t: diagnosticCenter.getTests()) {
				//inserting data into test table
				pstmt=conn.prepareStatement(DBQuery.TEST_INSERT_QUERY);
				//converting java object to table row form
				pstmt.setInt(1, t.getId());
				pstmt.setString(2, t.getName());
				pstmt.setBigDecimal(3, t.getCost());
				pstmt.setInt(4, diagnosticCenter.getId());
				pstmt.executeUpdate();
			}
			if(i==1)
				System.out.println("Record inserted...!!");
		} catch (SQLException e) {
			System.out.println("Problem occurred during insertion..");
		}
		catch(ConnectionException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}finally {
			//closing all the DB connection 
			if(pstmt!=null && conn!=null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					throw new ConnectionException("Problem occurred in Connection");
				}
			}
		}
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
		try {
			//creating connection to DB
			conn=DBUtil.getConnection();
			//Creating object of prepared statement
			pstmt=conn.prepareStatement(DBQuery.FIND_BY_LOCATION);
			//setting parameter
			pstmt.setString(1, location);
			//executing prepared statement query
			rs=pstmt.executeQuery();
			if(rs!=null) {
				//iterating result set
				while(rs.next()) {
					DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
					diagnosticCenters.add(diagnosticCenter);
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}
		catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//closing connection from DB
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					throw new ConnectionException("Problem occurred in Connection");
				}
			}
		}
		return diagnosticCenters;
	}

	public List<DiagnosticCenter> findByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
		try {
			//creating connection to DB
			conn=DBUtil.getConnection();
			//creating prepared statement object
			pstmt=conn.prepareStatement(DBQuery.FIND_BY_TEST);
			//setting parameter
			pstmt.setString(1, name);
			//executing query
			rs=pstmt.executeQuery();
			if(rs!=null) {
				//iterating over the result set 
				while(rs.next()) {
					//converting table row data into object form
					DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
					List<Test> tests=new ArrayList<Test>();
					Test test=new Test();
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
					test.setId(rs.getInt(5));
					test.setName(rs.getString(6));
					test.setCost(new BigDecimal(rs.getString(7)));
					tests.add(test);
					diagnosticCenter.setTests(tests);
					diagnosticCenters.add(diagnosticCenter);
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}
		catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//closing all the connection from DB
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					throw new ConnectionException("Problem occurred in Connection");
				}
			}
		}
		return diagnosticCenters;
	}

	public DiagnosticCenter findById(int id) {
		DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
		try {
			//creating connection to DB
			conn=DBUtil.getConnection();
			//creating prepared statement object
			pstmt=conn.prepareStatement(DBQuery.DIAGNOSTIC_FIND_BY_ID);
			//setting parameter 
			pstmt.setInt(1, id);
			//executing prepared statement
			rs=pstmt.executeQuery();
			if(rs!=null) {
				//iterating over result set
				while(rs.next()) {
					//converting row data into object
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//closing the connection
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					throw new ConnectionException("Problem occurred in Connection");
				}
			}
		}
		return diagnosticCenter;
	}
	
}
