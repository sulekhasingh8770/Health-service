package com.cg.healthservice.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		try {
			conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(INSERT_QUERY);
			pstmt.setInt(1, diagnosticCenter.getId());
			pstmt.setString(2, diagnosticCenter.getName());
			pstmt.setString(3, diagnosticCenter.getLocation());
			pstmt.setString(4,diagnosticCenter.getContact().toString());
			int i=pstmt.executeUpdate();
			for(Test t: diagnosticCenter.getTests()) {
				pstmt=conn.prepareStatement("insert into test values(?,?,?,?)");
				pstmt.setInt(1, t.getId());
				pstmt.setString(2, t.getName());
				pstmt.setBigDecimal(3, t.getCost());
				pstmt.setInt(4, diagnosticCenter.getId());
				pstmt.executeUpdate();
			}
			if(i==1)
				System.out.println("Record inserted...!!");
		} catch (SQLException e) {
			System.out.println("Problem occurred during insertion..");
		}
		catch(ConnectionException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}finally {
			if(pstmt!=null && conn!=null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
		try {
			conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(FIND_BY_LOCATION);
			pstmt.setString(1, location);
			rs=pstmt.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
					diagnosticCenters.add(diagnosticCenter);
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}
		catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return diagnosticCenters;
	}

	public List<DiagnosticCenter> findByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
		try {
			conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(FIND_BY_TEST);
			pstmt.setString(1, name);
			rs=pstmt.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
					List<Test> tests=new ArrayList<Test>();
					Test test=new Test();
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
					test.setId(rs.getInt(5));
					test.setName(rs.getString(6));
					test.setCost(new BigDecimal(rs.getString(7)));
					tests.add(test);
					diagnosticCenter.setTests(tests);
					diagnosticCenters.add(diagnosticCenter);
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}
		catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return diagnosticCenters;
	}

	public DiagnosticCenter findById(int id) {
		DiagnosticCenter diagnosticCenter=new DiagnosticCenter();
		try {
			conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(FIND_BY_ID);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					diagnosticCenter.setId(rs.getInt(1));
					diagnosticCenter.setName(rs.getString(2));
					diagnosticCenter.setLocation(rs.getString(3));
					diagnosticCenter.setContact(new BigInteger(rs.getString(4)));
				}
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return diagnosticCenter;
	}
	
}
