package com.cg.healthservice.util;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.dto.Test;

public class DBUtil {

	static List<Test> tests=new ArrayList<Test>();
	
	public static Connection getConnection() {
		Connection conn=null;

		Properties prop=new Properties();
		try {
			FileInputStream is=new FileInputStream("src/main/resources/jdbc.properties");
			prop.load(is);
				if(prop!=null) {
					String driver=prop.getProperty("driver");
					String url=prop.getProperty("url");
					String user=prop.getProperty("username");
					String password=prop.getProperty("password");
					Class.forName(driver);
					conn=DriverManager.getConnection(url, user, password);
				}
		} catch(Exception e) {
			try {
				throw new ConnectException("Connection not stablished..!!");
			} catch (ConnectException e1) {
				e1.getMessage();
			}
		}
		return conn;
	}

}
