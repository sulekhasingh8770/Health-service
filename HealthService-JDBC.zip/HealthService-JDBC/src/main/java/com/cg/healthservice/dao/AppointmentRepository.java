package com.cg.healthservice.dao;


import com.cg.healthservice.dto.Appointment;

public interface AppointmentRepository {

	public static final String INSERT_QUERY="insert into appointment values(?,?,?,?)";
	public Appointment save(Appointment appointment);
}
