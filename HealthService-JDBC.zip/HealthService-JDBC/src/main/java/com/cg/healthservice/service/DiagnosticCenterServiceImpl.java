package com.cg.healthservice.service;

import java.util.List;
import com.cg.healthservice.dao.DiagnosticCenterRepositoryImpl;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;

public class DiagnosticCenterServiceImpl implements DiagnosticCenterService {

	DiagnosticCenterRepositoryImpl dao;
	
	public DiagnosticCenterServiceImpl() {
		dao=new DiagnosticCenterRepositoryImpl();
	}

	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		return dao.save(diagnosticCenter);
	}

	public List<DiagnosticCenter> searchByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByLocation(location);
		if(diagnosticCenters.isEmpty())
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		return diagnosticCenters;
	}

	public List<DiagnosticCenter> searchByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByTest(name);
		if(diagnosticCenters.isEmpty())
			throw new NoTestMatchingDiagnosticCenterFound("Matching Diagnostic center Not found");
		return diagnosticCenters;
	}

	public DiagnosticCenter searchById(int id) {
		DiagnosticCenter diagnosticCenter=dao.findById(id);
		if(diagnosticCenter==null)
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		return diagnosticCenter;
	}

}
