package com.cg.healthservice.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.util.DBUtil;

public class PatientRepositoryImpl implements PatientRepository {

	Connection conn=DBUtil.getConnection();
	PreparedStatement pstmt;
	ResultSet rs;
	public Patient save(Patient patient) {
		try {
			Connection conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(INSERT_QUERY);
			pstmt.setInt(1, patient.getId());
			pstmt.setString(2, patient.getName());
			pstmt.setString(3, patient.getAddress());
			pstmt.setString(4,patient.getContact().toString());
			pstmt.setString(5, patient.getEmail());
			int i=pstmt.executeUpdate();
			if(i==1)
				System.out.println("Record inserted...!!");
		} catch (SQLException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && conn!=null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return patient;
	}

	public List<Patient> findByName(String name) {
		List<Patient> patients=new ArrayList<Patient>();
		try {
			Connection conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(FIND_BY_NAME_QUERY);
			pstmt.setString(1, name);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				Patient patient=new Patient();
				patient.setId(rs.getInt(1));
				patient.setName(rs.getString(2));
				patient.setAddress(rs.getString(3));
				patient.setContact(new BigInteger(rs.getString(4)));
				patient.setEmail(rs.getString(5));
				patients.add(patient);
			}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return patients;
	}

	public Patient findById(int id) {
		Patient patient=null;
		try {
			Connection conn=DBUtil.getConnection();
			pstmt=conn.prepareStatement(FIND_BY_ID_QUERY);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			if(rs!=null)
				while(rs.next()) {
					patient=new Patient(rs.getInt(1), rs.getString(2), rs.getString(3),
							new BigInteger(rs.getString(4)), rs.getString(5));
				}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return patient;
	}

	
}
