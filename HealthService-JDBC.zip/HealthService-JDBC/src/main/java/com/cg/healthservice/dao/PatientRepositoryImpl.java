package com.cg.healthservice.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class PatientRepositoryImpl implements PatientRepository {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	public Patient save(Patient patient) {
		try {//creating connection to DB
			conn=DBUtil.getConnection();
			//creating prepared statement object
			pstmt=conn.prepareStatement(DBQuery.INSERT_QUERY);
			//converting java object into DB specific data
			pstmt.setInt(1, patient.getId());
			pstmt.setString(2, patient.getName());
			pstmt.setString(3, patient.getAddress());
			pstmt.setString(4,patient.getContact().toString());
			pstmt.setString(5, patient.getEmail());
			//executing prepared statement
			int i=pstmt.executeUpdate();
			if(i==1)
				System.out.println("Record inserted...!!");
		} catch (SQLException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//closing connection from DB
			if(pstmt!=null && conn!=null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return patient;
	}

	public List<Patient> findByName(String name) {
		List<Patient> patients=new ArrayList<Patient>();
		try {
			//creating connection
			conn=DBUtil.getConnection();
			//creating prepared statement object
			pstmt=conn.prepareStatement(DBQuery.FIND_BY_NAME_QUERY);
			//setting parameter
			pstmt.setString(1, name);
			//executing prepared statement
			ResultSet rs=pstmt.executeQuery();
			//iterating over the result set
			if(rs!=null)
				while(rs.next()) {
					//converting result set data into java object 
					Patient patient=new Patient();
					patient.setId(rs.getInt(1));
					patient.setName(rs.getString(2));
					patient.setAddress(rs.getString(3));
					patient.setContact(new BigInteger(rs.getString(4)));
					patient.setEmail(rs.getString(5));
					patients.add(patient);
				}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//close connection from DB 
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return patients;
	}

	public Patient findById(int id) {
		Patient patient=null;
		try {
			//create connection to DB
			conn=DBUtil.getConnection();
			//create Prepared statement object
			pstmt=conn.prepareStatement(DBQuery.FIND_BY_ID_QUERY);
			//setting parameter value
			pstmt.setInt(1, id);
			//executing query
			rs=pstmt.executeQuery();
			//iterating over result set
			if(rs!=null)
				while(rs.next()) {
					patient=new Patient(rs.getInt(1), rs.getString(2), rs.getString(3),
							new BigInteger(rs.getString(4)), rs.getString(5));
				}
		} catch (SQLException e) {
			throw new ConnectionException("Problem occurred during data retrieve");
		}catch(ConnectionException e) {
			e.getMessage();
		}finally {
			//closing connection from DB
			if(pstmt!=null && rs!=null && conn!=null) {
				try {
					pstmt.close();
					rs.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return patient;
	}

	
}
