package com.cg.healthservice.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.util.DBQuery;
import com.cg.healthservice.util.DBUtil;

public class AppointmentRepositoryImpl implements AppointmentRepository {

	
	Connection conn;
	PreparedStatement pstmt;
	public Appointment save(Appointment appointment) {

		try {
			//creating connection to the DB
			conn=DBUtil.getConnection();
			//creating query
			pstmt=conn.prepareStatement(DBQuery.APPOINTMENT_INSERT_QUERY);
			//converting java object to table row data
			pstmt.setInt(1, appointment.getId());
			pstmt.setInt(2, appointment.getPatient().getId());
			pstmt.setInt(3, appointment.getDiagnosticCenter().getId());
			pstmt.setDate(4, Date.valueOf(appointment.getDate()));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}finally {
			//closing all the DB connection 
			if(pstmt!=null && conn!=null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					throw new ConnectionException("Problem occurred in Connection");
				}
			}
		}
		return appointment;
	}


}
