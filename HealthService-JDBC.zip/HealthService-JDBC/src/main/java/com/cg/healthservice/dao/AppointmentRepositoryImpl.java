package com.cg.healthservice.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.exception.InsertionFailedException;
import com.cg.healthservice.util.DBUtil;

public class AppointmentRepositoryImpl implements AppointmentRepository {

	Connection conn=DBUtil.getConnection();
	PreparedStatement pstmt;
	public Appointment save(Appointment appointment) {

		try {
			pstmt=conn.prepareStatement(INSERT_QUERY);
			pstmt.setInt(1, appointment.getId());
			pstmt.setInt(2, appointment.getPatient().getId());
			pstmt.setInt(3, appointment.getDiagnosticCenter().getId());
			pstmt.setDate(4, Date.valueOf(appointment.getDate()));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new InsertionFailedException("Problem occurred during insertion of data..!");
		}
		return appointment;
	}


}
