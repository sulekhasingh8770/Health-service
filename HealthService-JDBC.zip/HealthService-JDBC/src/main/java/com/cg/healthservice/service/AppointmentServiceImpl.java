package com.cg.healthservice.service;

import com.cg.healthservice.dao.AppointmentRepository;
import com.cg.healthservice.dao.AppointmentRepositoryImpl;
import com.cg.healthservice.dto.Appointment;

public class AppointmentServiceImpl implements AppointmentService {

	AppointmentRepository dao;
	
	public AppointmentServiceImpl() {
		dao=new AppointmentRepositoryImpl();
	}

	public Appointment addAppointment(Appointment appointment) {
		return dao.save(appointment);
	}
}
