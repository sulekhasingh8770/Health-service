package com.cg.healthservice.service;

import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;

public interface PatientService {

	public Patient addPatient(Patient patient);
	public List<Patient> searchByName(String name);
	public Patient searchById(int id);
}
