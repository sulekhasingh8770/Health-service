package com.cg.healthservice.dao;


import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.util.DBUtil;

public class AppointmentRepositoryImpl implements AppointmentRepository {

	public Appointment save(Appointment appointment) {
		DBUtil.appointments.add(appointment);
		return appointment;
	}

}
