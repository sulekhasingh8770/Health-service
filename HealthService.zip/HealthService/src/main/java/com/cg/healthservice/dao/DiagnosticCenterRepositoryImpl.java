package com.cg.healthservice.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;
import com.cg.healthservice.util.DBUtil;

public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {
	
	List<DiagnosticCenter> locationList;
	List<DiagnosticCenter> testList;
	
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		DBUtil.diagnosticCenters.add(diagnosticCenter);
		return diagnosticCenter;
	}

	public List<DiagnosticCenter> findByLocation(String location) {
		locationList=new ArrayList<DiagnosticCenter>();
		for(DiagnosticCenter d: DBUtil.diagnosticCenters) 
			if(d.getLocation().equalsIgnoreCase(location)) 
				locationList.add(d);
		return locationList;
	}

	public List<DiagnosticCenter> findByTest(String name) {
		testList=new ArrayList<DiagnosticCenter>();
		for(DiagnosticCenter d: DBUtil.diagnosticCenters) {
			for(Test t: d.getTests())
				if(t.getName().equalsIgnoreCase(name))
					testList.add(d);
		}
		return testList;
	}

	public DiagnosticCenter findById(int id) {
		for(DiagnosticCenter d: DBUtil.diagnosticCenters)
			if(d.getId()==id)
				return d;
		return null;
	}

	
}
