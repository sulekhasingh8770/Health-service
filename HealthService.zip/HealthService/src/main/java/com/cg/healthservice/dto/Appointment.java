package com.cg.healthservice.dto;

import java.time.LocalDate;

public class Appointment {

	private int id;
	private DiagnosticCenter diagnosticCenter;
	private Patient patient;
	private LocalDate date;
	
	public Appointment() {
		super();
	}

	public Appointment(int id, DiagnosticCenter diagnosticCenter, Patient patient, LocalDate date) {
		super();
		this.id = id;
		this.diagnosticCenter = diagnosticCenter;
		this.patient = patient;
		this.date = date;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public DiagnosticCenter getDiagnosticCenter() {
		return diagnosticCenter;
	}

	public void setDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		this.diagnosticCenter = diagnosticCenter;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", diagnosticCenter=" + diagnosticCenter + ", patient=" + patient + ", date="
				+ date + "]";
	}
	
}
