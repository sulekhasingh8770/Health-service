package com.cg.healthservice.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.NameNotFoundException;
import com.cg.healthservice.util.DBUtil;

public class PatientRepositoryImpl implements PatientRepository {

	List<Patient> nameList;
	
	public PatientRepositoryImpl() {
		DBUtil.patients=new ArrayList<Patient>();
	}

	public Patient save(Patient patient) {
		DBUtil.patients.add(patient);
		return patient;
	}

	public List<Patient> findByName(String name) {
		nameList=new ArrayList<Patient>();
		for(Patient p: DBUtil.patients) 
			if(p.getName().equalsIgnoreCase(name)) 
				nameList.add(p);
		
		return nameList;
	}

	public Patient findById(int id) {
		for(Patient p: DBUtil.patients)
			if(p.getId()==id)
				return p;
		return null;
	}

}
