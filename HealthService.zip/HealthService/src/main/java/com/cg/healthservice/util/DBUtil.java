package com.cg.healthservice.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.dto.Test;

public class DBUtil {

	public static List<Patient> patients=new ArrayList<Patient>();
	public static List<DiagnosticCenter> diagnosticCenters=new ArrayList<DiagnosticCenter>();
	public static List<Appointment> appointments=new ArrayList<Appointment>();
	public static List<Test> tests=new ArrayList<Test>();
	
	static {
		patients.add(new Patient(101, "Sulekha", "Talwade", new BigInteger("90897657129"), "sulekha@gmail.com"));
		patients.add(new Patient(102, "buntu", "hinjewadi", new BigInteger("90897657129"), "buntu@gmail.com"));
		patients.add(new Patient(101, "Xyz", "pune", new BigInteger("90897657129"), "xyz@gmail.com"));
		tests.add(new Test(110, "CBC", new BigDecimal(34900.0)));
		tests.add(new Test(111, "thyroid", new BigDecimal(30000.0)));
		tests.add(new Test(112, "blood test", new BigDecimal(50000.0)));
		tests.add(new Test(113, "Xray", new BigDecimal(5000.0)));
		diagnosticCenters.add(new DiagnosticCenter(1100, "SRDiagnostics", "pune", new BigInteger("2323908766"), tests));
	}
}
